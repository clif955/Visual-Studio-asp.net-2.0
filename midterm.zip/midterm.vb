
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim verifystate As Boolean
    Dim verifyzip As Boolean
    Dim verifyphonenumber As Boolean
    Dim verifysocialsecuritynumber As Boolean
    Dim verifyemail As Boolean


    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim stateinputbox As Boolean
        Dim length As String = stateinputbox.length
        If stateinputbox = 2 Then Response.Write("state is valid")
        Else
        Response.Write("instate is invalid")
        End If

        Dim zipcodebox As Boolean
        Dim length As Integer = zipcodebox.length
        If zipcodebox = 5 Or 9 Then Response.Write("zip is valid")
        else 
        Response.Write("zip is invalid")
        end if




    End Sub


    Protected Sub emailaddressbox_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles emailaddressbox.TextChanged

    End Sub

    Protected Sub stateinputbox_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles stateinputbox.TextChanged

    End Sub
End Class
