
Partial Class newuser
    Inherits System.Web.UI.Page

End Class
